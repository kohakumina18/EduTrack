/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teacherdashboard_v2;

/**
 *
 * @author nvakt
 */
public class TeacherDashboard_V2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
