/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.teacherdashboard_v2.Frames;

/**
 *
 * @author nvakt
 */
public class SampleResultSet {
    private Object[][] data;
    private String[] columnNames;
    private int currentRow;

    public SampleResultSet(Object[][] sampleData, String[] columnNames) {
        this.data = sampleData;
        this.columnNames = columnNames;
        this.currentRow = -1; // Start before the first row
    }

    // Method to check if there are more rows
    public boolean next() {
        return currentRow < data.length - 1;
    }

    // Method to move to the next row
    public void moveToNext() {
        currentRow++;
    }

    // Method to get data from the current row for a specific column index
    public Object getObject(int columnIndex) {
        return data[currentRow][columnIndex];
    }

    // Method to get data from the current row for a specific column name
    public Object getObject(String columnName) {
        int columnIndex = getColumnIndex(columnName);
        return getObject(columnIndex);
    }

    // Method to get the index of a column by name
    private int getColumnIndex(String columnName) {
        for (int i = 0; i < columnNames.length; i++) {
            if (columnNames[i].equals(columnName)) {
                return i;
            }
        }
        throw new IllegalArgumentException("Column " + columnName + " not found");
    }
}
