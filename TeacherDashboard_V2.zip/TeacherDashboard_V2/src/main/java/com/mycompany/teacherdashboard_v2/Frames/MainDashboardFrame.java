package com.mycompany.teacherdashboard_v2.Frames;

import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;

public class MainDashboardFrame extends JFrame {

    // Define components
    private JPanel panelUpcomingClasses;
    private JPanel panelRecentUpdates;
    private JPanel panelNotifications;
    private JLabel labelUpcomingClasses;
    private JLabel labelRecentUpdates;
    private JLabel labelNotifications;
    private JTable tableUpcomingClasses;
    private JTextArea textAreaRecentUpdates;
    private JTextArea textAreaNotifications;
    private CardLayout cardLayout;
    private JPanel mainPanel;

    // Constructor
    public MainDashboardFrame() {
        initComponents();
        fetchSampleData(); // Fetch sample data upon frame initialization
    }

    // Method to initialize components
    private void initComponents() {
        // Initialize text areas for recent updates and notifications
        textAreaRecentUpdates = new JTextArea();
        JScrollPane scrollPaneUpdates = new JScrollPane(textAreaRecentUpdates);
        textAreaNotifications = new JTextArea(); // Initialize text area for notifications
        JScrollPane scrollPaneNotifications = new JScrollPane(textAreaNotifications); // Add a scroll pane for
                                                                                      // notifications

        // Set frame properties
        setTitle("Teacher Dashboard");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1000, 600));

        // Initialize panels
        panelUpcomingClasses = new JPanel(new BorderLayout());
        panelRecentUpdates = new JPanel(new BorderLayout());
        panelNotifications = new JPanel(new BorderLayout());

        // Initialize labels
        labelUpcomingClasses = new JLabel("Upcoming Classes", SwingConstants.CENTER);
        labelRecentUpdates = new JLabel("Recent Updates", SwingConstants.CENTER);
        labelNotifications = new JLabel("Notifications", SwingConstants.CENTER);

        // Initialize table for upcoming classes
        String[] columnNames = { "Class Name", "Date", "Time" };
        Object[][] data = {}; // Empty data initially
        tableUpcomingClasses = new JTable(data, columnNames);
        JScrollPane scrollPaneUpcoming = new JScrollPane(tableUpcomingClasses);
        panelUpcomingClasses.add(labelUpcomingClasses, BorderLayout.NORTH);
        panelUpcomingClasses.add(scrollPaneUpcoming, BorderLayout.CENTER);

        // Initialize buttons for recent updates and notifications
        JButton btnRecentUpdates = new JButton("View Updates");
        JButton btnNotifications = new JButton("View Notifications");

        // Add action listeners to buttons if needed

        // Add buttons to recent updates and notifications panels
        panelRecentUpdates.add(labelRecentUpdates, BorderLayout.NORTH);
        panelRecentUpdates.add(scrollPaneUpdates, BorderLayout.CENTER);
        panelNotifications.add(labelNotifications, BorderLayout.NORTH);
        panelNotifications.add(scrollPaneNotifications, BorderLayout.CENTER); // Add the scroll pane for notifications

        // Set layout for the frame
        getContentPane().setLayout(new BorderLayout());

        // Initialize the main panel and card layout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        // Add panels to frame
        mainPanel.add(panelUpcomingClasses, "UpcomingClasses");

        // Add buttons for each function beneath the calendar of the schedule
        addFunctionButtons();

        // Pack the components
        pack();
    }

    // Method to add buttons for each function
    private void addFunctionButtons() {
        JPanel panelFunctions = new JPanel(new GridLayout(4, 2));

        JButton btnClassSchedule = new JButton("Class Schedule");
        JButton btnClassManagement = new JButton("Class Management");
        JButton btnAttendanceTracking = new JButton("Attendance Tracking");
        JButton btnCommunicationTools = new JButton("Communication Tools");
        JButton btnResourceLibrary = new JButton("Resource Library");
        JButton btnProfessionalDevelopment = new JButton("Professional Development");
        JButton btnFeedbackEvaluation = new JButton("Feedback and Evaluation");
        JButton btnReportingAnalytics = new JButton("Reporting and Analytics");

        btnClassSchedule.addActionListener(e -> showClassSchedulePanel());
        btnClassManagement.addActionListener(e -> showClassManagementPanel());
        btnAttendanceTracking.addActionListener(e -> showAttendanceTrackingPanel());
        btnCommunicationTools.addActionListener(e -> showCommunicationToolsPanel());
        btnResourceLibrary.addActionListener(e -> showResourceLibraryPanel());
        btnProfessionalDevelopment.addActionListener(e -> showProfessionalDevelopmentPanel());
        btnFeedbackEvaluation.addActionListener(e -> showFeedbackEvaluationPanel());
        btnReportingAnalytics.addActionListener(e -> showReportingAnalyticsPanel());

        panelFunctions.add(btnClassSchedule);
        panelFunctions.add(btnClassManagement);
        panelFunctions.add(btnAttendanceTracking);
        panelFunctions.add(btnCommunicationTools);
        panelFunctions.add(btnResourceLibrary);
        panelFunctions.add(btnProfessionalDevelopment);
        panelFunctions.add(btnFeedbackEvaluation);
        panelFunctions.add(btnReportingAnalytics);

        getContentPane().add(panelFunctions, BorderLayout.SOUTH);
    }

 private void showClassSchedulePanel() {
    JPanel schedulePanel = new JPanel(new BorderLayout());

    // Calendar View
    JPanel calendarPanel = new JPanel();
    calendarPanel.add(new JLabel("Calendar View Placeholder"));

    // List of Classes with more sample data
    Object[][] sampleData = {
        { "English 101", "2024-05-14", "09:00 AM" },
        { "Business English", "2024-05-14", "10:00 AM" },
        { "IELTS 5.0 Preparation", "2024-05-14", "11:00 AM" },
        { "Conversational English", "2024-05-14", "01:00 PM" },
        { "Academic Writing", "2024-05-14", "02:00 PM" },
        { "TOEFL Preparation", "2024-05-15", "09:00 AM" },
        { "Pronunciation Workshop", "2024-05-15", "10:00 AM" },
        { "Advanced Grammar", "2024-05-15", "11:00 AM" },
        { "Listening Skills", "2024-05-15", "01:00 PM" },
        { "Reading Comprehension", "2024-05-15", "02:00 PM" },
        { "Vocabulary Building", "2024-05-16", "09:00 AM" },
        { "Presentation Skills", "2024-05-16", "10:00 AM" },
        { "Business English II", "2024-05-16", "11:00 AM" },
        { "IELTS 6.0 Preparation", "2024-05-16", "01:00 PM" },
        { "Creative Writing", "2024-05-16", "02:00 PM" }
    };

    DefaultTableModel tableModel = new DefaultTableModel(sampleData, new String[] { "Class Name", "Date", "Time" });
    JTable classTable = new JTable(tableModel);
    JScrollPane scrollPane = new JScrollPane(classTable);

    // Buttons Panel
    JPanel buttonsPanel = new JPanel();
    buttonsPanel.add(new JButton("Add"));
    buttonsPanel.add(new JButton("Edit"));
    buttonsPanel.add(new JButton("Delete"));
    buttonsPanel.add(new JButton("Export"));

    schedulePanel.add(calendarPanel, BorderLayout.NORTH);
    schedulePanel.add(scrollPane, BorderLayout.CENTER);
    schedulePanel.add(buttonsPanel, BorderLayout.SOUTH);

    mainPanel.add(schedulePanel, "ClassSchedule");
    cardLayout.show(mainPanel, "ClassSchedule");
}


   private void showClassManagementPanel() {
    JPanel managementPanel = new JPanel(new BorderLayout());

    // Class List with more sample data
    Object[][] sampleData = {
        { "TOEIC700.2", "Mr. Smith", 30 },
        { "Business English", "Ms. Johnson", 25 },
        { "IELTS 5.0 Preparation", "Mr. Brown", 20 },
        { "Conversational English", "Ms. Davis", 15 },
        { "Academic Writing", "Dr. Wilson", 18 },
        { "TOEFL Preparation", "Mr. Lee", 22 },
        { "Pronunciation Workshop", "Ms. White", 10 },
        { "Advanced Grammar", "Dr. Harris", 12 },
        { "Listening Skills", "Ms. Clark", 14 },
        { "Reading Comprehension", "Mr. Lewis", 16 },
        { "Vocabulary Building", "Ms. Walker", 28 },
        { "Presentation Skills", "Dr. Hall", 19 },
        { "Business English II", "Mr. Young", 27 },
        { "IELTS 6.0 Preparation", "Ms. King", 21 },
        { "Creative Writing", "Dr. Wright", 17 }
    };

    DefaultTableModel tableModel = new DefaultTableModel(sampleData, new String[] { "Class Name", "Teacher", "Students" });
    JTable classListTable = new JTable(tableModel);
    JScrollPane scrollPane = new JScrollPane(classListTable);

    // Buttons Panel
    JPanel buttonsPanel = new JPanel();
    buttonsPanel.add(new JButton("Add"));
    buttonsPanel.add(new JButton("Edit"));
    buttonsPanel.add(new JButton("Delete"));

    managementPanel.add(scrollPane, BorderLayout.CENTER);
    managementPanel.add(buttonsPanel, BorderLayout.SOUTH);

    mainPanel.add(managementPanel, "ClassManagement");
    cardLayout.show(mainPanel, "ClassManagement");
}


    private void showAttendanceTrackingPanel() {
        JPanel attendancePanel = new JPanel(new BorderLayout());

        // Attendance Table
        JTable attendanceTable = new JTable(new DefaultTableModel(
                new Object[][] { { "John Doe", "2024-05-14", "Present" } },
                new String[] { "Student Name", "Date", "Status" }));
        JScrollPane scrollPane = new JScrollPane(attendanceTable);

        // Date Picker and Save Button
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(new JLabel("Select Date:"));
        bottomPanel.add(new JTextField(10)); // Placeholder for a date picker
        bottomPanel.add(new JButton("Save"));

        attendancePanel.add(scrollPane, BorderLayout.CENTER);
        attendancePanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(attendancePanel, "AttendanceTracking");
        cardLayout.show(mainPanel, "AttendanceTracking");
    }

    private void showCommunicationToolsPanel() {
        JPanel communicationPanel = new JPanel(new BorderLayout());

        // Communication Tools
        JTextArea communicationTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(communicationTextArea);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(new JButton("Send Message"));
        buttonsPanel.add(new JButton("Email"));
        buttonsPanel.add(new JButton("Chat"));

        communicationPanel.add(scrollPane, BorderLayout.CENTER);
        communicationPanel.add(buttonsPanel, BorderLayout.SOUTH);

        mainPanel.add(communicationPanel, "CommunicationTools");
        cardLayout.show(mainPanel, "CommunicationTools");
    }

    private void showResourceLibraryPanel() {
        JPanel resourcePanel = new JPanel(new BorderLayout());

        // Resource List
        JTable resourceTable = new JTable(new DefaultTableModel(
                new Object[][] { { "Math Textbook", "PDF", "Download" } },
                new String[] { "Resource Name", "Type", "Action" }));
        JScrollPane scrollPane = new JScrollPane(resourceTable);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(new JButton("Upload"));
        buttonsPanel.add(new JButton("Edit"));
        buttonsPanel.add(new JButton("Delete"));

        resourcePanel.add(scrollPane, BorderLayout.CENTER);
        resourcePanel.add(buttonsPanel, BorderLayout.SOUTH);

        mainPanel.add(resourcePanel, "ResourceLibrary");
        cardLayout.show(mainPanel, "ResourceLibrary");
    }

    private void showProfessionalDevelopmentPanel() {
        JPanel developmentPanel = new JPanel(new BorderLayout());

        // Professional Development Activities List
        JTable developmentTable = new JTable(new DefaultTableModel(
                new Object[][] { { "Workshop on AI in Education", "2024-06-01", "Enroll" } },
                new String[] { "Activity", "Date", "Action" }));
        JScrollPane scrollPane = new JScrollPane(developmentTable);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(new JButton("Enroll"));
        buttonsPanel.add(new JButton("View Details"));

        developmentPanel.add(scrollPane, BorderLayout.CENTER);
        developmentPanel.add(buttonsPanel, BorderLayout.SOUTH);

        mainPanel.add(developmentPanel, "ProfessionalDevelopment");
        cardLayout.show(mainPanel, "ProfessionalDevelopment");
    }

    private void showFeedbackEvaluationPanel() {
        JPanel feedbackPanel = new JPanel(new BorderLayout());

        // Feedback List
        JTable feedbackTable = new JTable(new DefaultTableModel(
                new Object[][] { { "John Doe", "2024-05-14", "Great class!" } },
                new String[] { "Student Name", "Date", "Feedback" }));
        JScrollPane scrollPane = new JScrollPane(feedbackTable);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(new JButton("Add Feedback"));
        buttonsPanel.add(new JButton("View All Feedback"));

        feedbackPanel.add(scrollPane, BorderLayout.CENTER);
        feedbackPanel.add(buttonsPanel, BorderLayout.SOUTH);

        mainPanel.add(feedbackPanel, "FeedbackEvaluation");
        cardLayout.show(mainPanel, "FeedbackEvaluation");
    }

    private void showReportingAnalyticsPanel() {
        JPanel analyticsPanel = new JPanel(new BorderLayout());

        // Analytics Display (Placeholder for charts or graphs)
        JTextArea analyticsTextArea = new JTextArea();
        analyticsTextArea.setText("Analytics Data Placeholder");
        JScrollPane scrollPane = new JScrollPane(analyticsTextArea);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(new JButton("Generate Report"));
        buttonsPanel.add(new JButton("View Statistics"));

        analyticsPanel.add(scrollPane, BorderLayout.CENTER);
        analyticsPanel.add(buttonsPanel, BorderLayout.SOUTH);

        mainPanel.add(analyticsPanel, "ReportingAnalytics");
        cardLayout.show(mainPanel, "ReportingAnalytics");
    }

    // connect DB -> Fetch Data -> Display
    private void fetchSampleData() {
        // Sample data for demonstration
        String sampleUpdates = "Update 1: New assignment posted.\nUpdate 2: School holiday on 2024-05-25.";
        String sampleNotifications = "Notification 1: Parent-teacher meeting scheduled.\nNotification 2: Submit grades by 2024-05-20.";
        textAreaRecentUpdates.setText(sampleUpdates);
        textAreaNotifications.setText(sampleNotifications);

    }

    // Main method
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            new MainDashboardFrame().setVisible(true);
        });
    }
}
