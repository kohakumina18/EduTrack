/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.teacherdashboard_v2.Frames;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnector {
    private static final String URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static ResultSet getClassSchedules() throws SQLException {
        try {
            Connection connection = getConnection();
            String sql = "SELECT class_name, date, time FROM class_schedule";
            Statement statement = connection.createStatement();
            return statement.executeQuery(sql);
        } catch (SQLException ex) {
            System.err.println("Failed to connect to the database. Loading sample data...");
            return getSampleDataResultSet(); // Return sample data if connection fails
        }
    }

    private static ResultSet getSampleDataResultSet() {
        String[] columnNames = {"class_name", "date", "time"};
        Object[][] sampleData = {
                {"English 101", "2024-05-14", "09:00 AM"},
                {"IELTS 5.0+", "2024-05-15", "10:00 AM"},
                {"TOEIC 700+", "2024-05-16", "11:00 AM"}
        };

        try {
            CachedRowSet crs = RowSetProvider.newFactory().createCachedRowSet();
            crs.setUrl("jdbc:mysql://localhost:3306/your_database");
            crs.setUsername("your_username");
            crs.setPassword("your_password");
            
            crs.setCommand("SELECT ? AS class_name, ? AS date, ? AS time FROM dual");
            for (Object[] row : sampleData) {
                crs.setString(1, (String) row[0]);
                crs.setString(2, (String) row[1]);
                crs.setString(3, (String) row[2]);
                crs.execute();
            }

            return crs;
        } catch (SQLException e) {
            e.printStackTrace();
            return null; // Handle the exception accordingly in your application
        }
    }
}

